const STORAGE_KEY = "workforce-ops-dashboard-v1";

const seedData = {
  requests: [
    {
      id: crypto.randomUUID(),
      clientName: "동서물류",
      contactMethod: "전화",
      headcount: 3,
      siteLocation: "인천 남동공단",
      workDate: todayDate(),
      notes: "오전 7시 상차팀 필요",
      status: "대기"
    }
  ],
  workers: [
    { id: crypto.randomUUID(), name: "김민수", phone: "010-2711-9001", skill: "상하차" },
    { id: crypto.randomUUID(), name: "박지훈", phone: "010-4822-3344", skill: "지게차" },
    { id: crypto.randomUUID(), name: "이서연", phone: "010-7688-5521", skill: "포장" }
  ],
  assignments: [],
  attendance: []
};

const state = loadState();

const els = {
  requestForm: document.getElementById("requestForm"),
  requestsTable: document.getElementById("requestsTable"),
  workerForm: document.getElementById("workerForm"),
  workerChips: document.getElementById("workerChips"),
  assignmentForm: document.getElementById("assignmentForm"),
  assignmentRequestSelect: document.getElementById("assignmentRequestSelect"),
  assignmentWorkerSelect: document.getElementById("assignmentWorkerSelect"),
  assignmentList: document.getElementById("assignmentList"),
  reportTable: document.getElementById("reportTable"),
  reportClientFilter: document.getElementById("reportClientFilter"),
  clientSummaryGrid: document.getElementById("clientSummaryGrid"),
  manualEntryForm: document.getElementById("manualEntryForm"),
  manualAssignmentSelect: document.getElementById("manualAssignmentSelect"),
  manualStartTime: document.getElementById("manualStartTime"),
  manualEndTime: document.getElementById("manualEndTime"),
  manualBreakMinutes: document.getElementById("manualBreakMinutes"),
  manualPreview: document.getElementById("manualPreview"),
  manualEntryTable: document.getElementById("manualEntryTable"),
  exportCsvBtn: document.getElementById("exportCsvBtn"),
  heroStats: document.getElementById("heroStats"),
  assignmentCardTemplate: document.getElementById("assignmentCardTemplate")
};

bindEvents();
renderAll();

function bindEvents() {
  if (els.requestForm) {
    els.requestForm.addEventListener("submit", handleRequestSubmit);
  }
  if (els.workerForm) {
    els.workerForm.addEventListener("submit", handleWorkerSubmit);
  }
  if (els.assignmentForm) {
    els.assignmentForm.addEventListener("submit", handleAssignmentSubmit);
  }
  if (els.manualEntryForm) {
    els.manualEntryForm.addEventListener("submit", handleManualEntrySubmit);
  }
  if (els.reportClientFilter) {
    els.reportClientFilter.addEventListener("change", () => {
      renderClientSummary();
      renderReports();
    });
  }
  if (els.exportCsvBtn) {
    els.exportCsvBtn.addEventListener("click", exportCsv);
  }
  if (els.manualAssignmentSelect) {
    els.manualAssignmentSelect.addEventListener("change", updateManualPreview);
  }
  if (els.manualStartTime) {
    els.manualStartTime.addEventListener("input", updateManualPreview);
  }
  if (els.manualEndTime) {
    els.manualEndTime.addEventListener("input", updateManualPreview);
  }
  if (els.manualBreakMinutes) {
    els.manualBreakMinutes.addEventListener("input", updateManualPreview);
  }
}

function handleRequestSubmit(event) {
  event.preventDefault();
  const formData = new FormData(event.currentTarget);
  state.requests.unshift({
    id: crypto.randomUUID(),
    clientName: formData.get("clientName").trim(),
    contactMethod: formData.get("contactMethod"),
    headcount: Number(formData.get("headcount")),
    siteLocation: formData.get("siteLocation").trim(),
    workDate: formData.get("workDate"),
    notes: formData.get("notes").trim(),
    status: "대기"
  });
  event.currentTarget.reset();
  saveAndRender();
}

function handleWorkerSubmit(event) {
  event.preventDefault();
  const formData = new FormData(event.currentTarget);
  state.workers.push({
    id: crypto.randomUUID(),
    name: formData.get("name").trim(),
    phone: formData.get("phone").trim(),
    skill: formData.get("skill").trim()
  });
  event.currentTarget.reset();
  saveAndRender();
}

function handleAssignmentSubmit(event) {
  event.preventDefault();
  const formData = new FormData(event.currentTarget);
  const requestId = formData.get("requestId");
  const workerIds = Array.from(els.assignmentWorkerSelect.selectedOptions).map((option) => option.value);
  if (!requestId || workerIds.length === 0) {
    return;
  }

  const request = state.requests.find((item) => item.id === requestId);
  if (!request) {
    return;
  }

  workerIds.forEach((workerId) => {
    const existing = state.assignments.find(
      (item) => item.requestId === requestId && item.workerId === workerId
    );
    if (existing) {
      return;
    }

    const assignmentId = crypto.randomUUID();
    state.assignments.push({
      id: assignmentId,
      requestId,
      workerId,
      createdAt: new Date().toISOString()
    });
    state.attendance.push({
      assignmentId,
      checkIn: "",
      checkOut: "",
      manualStartTime: "",
      manualEndTime: "",
      breakMinutes: 0,
      workHours: 0,
      gongsu: 0
    });
  });

  request.status = `${countAssignedWorkers(requestId)}명 배정`;
  event.currentTarget.reset();
  saveAndRender();
}

function handleManualEntrySubmit(event) {
  event.preventDefault();
  const formData = new FormData(event.currentTarget);
  const assignmentId = formData.get("assignmentId");
  const startTime = formData.get("startTime");
  const endTime = formData.get("endTime");
  const breakMinutes = Number(formData.get("breakMinutes") || 0);
  const record = state.attendance.find((item) => item.assignmentId === assignmentId);
  if (!record) {
    return;
  }

  const result = calculateWorkMetrics(startTime, endTime, breakMinutes);
  if (!result) {
    return;
  }

  record.manualStartTime = startTime;
  record.manualEndTime = endTime;
  record.breakMinutes = breakMinutes;
  record.workHours = result.workHours;
  record.gongsu = result.gongsu;
  record.checkIn = record.checkIn || new Date(startTime).toISOString();
  record.checkOut = new Date(endTime).toISOString();

  saveAndRender();
}

function renderAll() {
  renderStats();
  renderRequests();
  renderWorkers();
  renderAssignmentOptions();
  renderAssignments();
  renderClientFilter();
  renderClientSummary();
  renderReports();
  renderManualEntryOptions();
  renderManualEntryTable();
  updateManualPreview();
}

function renderStats() {
  if (!els.heroStats) {
    return;
  }

  const assignedCount = state.assignments.length;
  const workedCount = state.attendance.filter((item) => item.workHours > 0).length;
  const totalGongsu = state.attendance.reduce((sum, item) => sum + Number(item.gongsu || 0), 0);
  const statItems = [
    ["접수 요청", `${state.requests.length}건`],
    ["배정 인력", `${assignedCount}명`],
    ["근무 입력", `${workedCount}명`],
    ["총 공수", `${totalGongsu.toFixed(1)}`],
    ["등록 인력", `${state.workers.length}명`]
  ];
  els.heroStats.innerHTML = statItems
    .map(
      ([label, value]) => `
        <article class="stat-card">
          <strong>${value}</strong>
          <span>${label}</span>
        </article>
      `
    )
    .join("");
}

function renderRequests() {
  if (!els.requestsTable) {
    return;
  }

  if (state.requests.length === 0) {
    els.requestsTable.innerHTML = emptyRow("등록된 요청이 없습니다.", 6);
    return;
  }

  els.requestsTable.innerHTML = state.requests
    .map(
      (request) => `
        <tr>
          <td>${escapeHtml(request.clientName)}</td>
          <td>${request.contactMethod}</td>
          <td>${request.headcount}명</td>
          <td>${escapeHtml(request.siteLocation)}</td>
          <td>${formatDate(request.workDate)}</td>
          <td>${renderStatus(request.status)}</td>
        </tr>
      `
    )
    .join("");
}

function renderWorkers() {
  if (!els.workerChips) {
    return;
  }

  if (state.workers.length === 0) {
    els.workerChips.innerHTML = `<p class="empty">등록된 인력이 없습니다.</p>`;
    return;
  }

  els.workerChips.innerHTML = state.workers
    .map(
      (worker) => `
        <span class="chip">${escapeHtml(worker.name)} · ${escapeHtml(worker.skill || "일반")}</span>
      `
    )
    .join("");
}

function renderAssignmentOptions() {
  if (!els.assignmentRequestSelect || !els.assignmentWorkerSelect) {
    return;
  }

  const requestOptions = state.requests
    .map(
      (request) => `
        <option value="${request.id}">
          ${request.clientName} / ${request.siteLocation} / ${request.headcount}명
        </option>
      `
    )
    .join("");
  const workerOptions = state.workers
    .map(
      (worker) => `
        <option value="${worker.id}">${worker.name} (${worker.skill || "일반"})</option>
      `
    )
    .join("");

  els.assignmentRequestSelect.innerHTML = requestOptions || `<option value="">요청이 없습니다</option>`;
  els.assignmentWorkerSelect.innerHTML = workerOptions || `<option value="">인력이 없습니다</option>`;
}

function renderAssignments() {
  if (!els.assignmentList || !els.assignmentCardTemplate) {
    return;
  }

  if (state.assignments.length === 0) {
    els.assignmentList.innerHTML = `<p class="empty">아직 배정된 인력이 없습니다.</p>`;
    return;
  }

  const cardsByRequest = state.requests
    .filter((request) => state.assignments.some((assignment) => assignment.requestId === request.id))
    .map((request) => {
      const fragment = els.assignmentCardTemplate.content.cloneNode(true);
      const assignedWorkers = state.assignments
        .filter((assignment) => assignment.requestId === request.id)
        .map((assignment) => getWorker(assignment.workerId))
        .filter(Boolean);

      fragment.querySelector("h3").textContent = request.clientName;
      fragment.querySelector(".badge").textContent = `${assignedWorkers.length}/${request.headcount}명`;
      fragment.querySelector(".assignment-meta").textContent =
        `${request.siteLocation} · ${formatDate(request.workDate)}`;
      fragment.querySelector(".assigned-workers").innerHTML = assignedWorkers
        .map(
          (worker) =>
            `<span class="worker-tag">${escapeHtml(worker.name)} · ${escapeHtml(
              worker.skill || "일반"
            )}</span>`
        )
        .join("");
      return fragment.firstElementChild.outerHTML;
    });

  els.assignmentList.innerHTML = cardsByRequest.join("");
}

function renderClientFilter() {
  if (!els.reportClientFilter) {
    return;
  }

  const clientNames = [...new Set(state.requests.map((request) => request.clientName))];
  const options = ['<option value="all">전체 거래처</option>']
    .concat(clientNames.map((name) => `<option value="${name}">${name}</option>`))
    .join("");
  const currentValue = els.reportClientFilter.value || "all";
  els.reportClientFilter.innerHTML = options;
  els.reportClientFilter.value = clientNames.includes(currentValue) || currentValue === "all" ? currentValue : "all";
}

function renderReports() {
  if (!els.reportTable) {
    return;
  }

  const rows = getReportRows();

  if (rows.length === 0) {
    els.reportTable.innerHTML = emptyRow("조회할 데이터가 없습니다.", 6);
    return;
  }

  els.reportTable.innerHTML = rows
    .map(
      (row) => `
        <tr>
          <td>${escapeHtml(row.clientName)}</td>
          <td>${formatDate(row.workDate)}</td>
          <td>${escapeHtml(row.siteLocation)}</td>
          <td>${escapeHtml(row.workerName)}</td>
          <td>${formatDateTime(row.checkIn)}</td>
          <td>${formatDateTime(row.checkOut)}</td>
          <td>${formatHours(row.workHours)}</td>
          <td>${formatGongsu(row.gongsu)}</td>
        </tr>
      `
    )
    .join("");
}

function exportCsv() {
  const rows = getReportRows().map((row) => [
    row.clientName,
    formatDate(row.workDate),
    row.siteLocation,
    row.workerName,
    formatDateTime(row.checkIn),
    formatDateTime(row.checkOut),
    formatHours(row.workHours),
    formatGongsu(row.gongsu)
  ]);

  const csvLines = [["거래처명", "근무일", "현장 위치", "인력명", "출근시간", "퇴근시간", "실근무시간", "공수"], ...rows]
    .map((line) => line.map((item) => `"${String(item).replaceAll('"', '""')}"`).join(","))
    .join("\n");

  const blob = new Blob(["\uFEFF" + csvLines], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `attendance-report-${new Date().toISOString().slice(0, 10)}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

function renderClientSummary() {
  if (!els.clientSummaryGrid) {
    return;
  }

  const rows = getReportRows();
  if (rows.length === 0) {
    els.clientSummaryGrid.innerHTML = `<p class="empty">거래처별 근무 요약이 아직 없습니다.</p>`;
    return;
  }

  const grouped = new Map();
  rows.forEach((row) => {
    const clientBucket = grouped.get(row.clientName) || new Map();
    const dateKey = row.workDate || "";
    const dateBucket = clientBucket.get(dateKey) || [];
    dateBucket.push(row.workerName);
    clientBucket.set(dateKey, dateBucket);
    grouped.set(row.clientName, clientBucket);
  });

  els.clientSummaryGrid.innerHTML = Array.from(grouped.entries())
    .map(([clientName, dates]) => {
      const items = Array.from(dates.entries())
        .sort((a, b) => String(a[0]).localeCompare(String(b[0])))
        .map(
          ([workDate, workerNames]) => `
            <div class="summary-item">
              <strong>${formatDate(workDate)}</strong>
              <span>${workerNames.join(", ")}</span>
            </div>
          `
        )
        .join("");

      return `
        <article class="summary-card">
          <h3>${escapeHtml(clientName)}</h3>
          <p>${dates.size}일 근무 기록</p>
          <div class="summary-items">${items}</div>
        </article>
      `;
    })
    .join("");
}

function getReportRows() {
  const filterValue = els.reportClientFilter.value || "all";
  return state.assignments
    .map((assignment) => {
      const request = getRequest(assignment.requestId);
      const worker = getWorker(assignment.workerId);
      const attendance = state.attendance.find((item) => item.assignmentId === assignment.id);
      return {
        clientName: request?.clientName || "-",
        workDate: request?.workDate || "",
        siteLocation: request?.siteLocation || "-",
        workerName: worker?.name || "-",
        checkIn: attendance?.manualStartTime || attendance?.checkIn || "",
        checkOut: attendance?.manualEndTime || attendance?.checkOut || "",
        workHours: Number(attendance?.workHours || 0),
        gongsu: Number(attendance?.gongsu || 0)
      };
    })
    .filter((row) => filterValue === "all" || row.clientName === filterValue)
    .sort((a, b) => {
      const dateCompare = String(a.workDate).localeCompare(String(b.workDate));
      if (dateCompare !== 0) {
        return dateCompare;
      }
      const clientCompare = a.clientName.localeCompare(b.clientName, "ko");
      if (clientCompare !== 0) {
        return clientCompare;
      }
      return a.workerName.localeCompare(b.workerName, "ko");
    });
}

function renderManualEntryOptions() {
  if (!els.manualAssignmentSelect) {
    return;
  }

  if (state.assignments.length === 0) {
    els.manualAssignmentSelect.innerHTML = `<option value="">배정된 내역이 없습니다</option>`;
    return;
  }

  els.manualAssignmentSelect.innerHTML = state.assignments
    .map((assignment) => {
      const request = getRequest(assignment.requestId);
      const worker = getWorker(assignment.workerId);
      return `
        <option value="${assignment.id}">
          ${worker?.name || "-"} / ${request?.clientName || "-"} / ${formatDate(request?.workDate || "")}
        </option>
      `;
    })
    .join("");
}

function renderManualEntryTable() {
  if (!els.manualEntryTable) {
    return;
  }

  const rows = getReportRows().filter((row) => row.workHours > 0 || row.gongsu > 0);
  if (rows.length === 0) {
    els.manualEntryTable.innerHTML = emptyRow("아직 입력된 근무시간이 없습니다.", 5);
    return;
  }

  els.manualEntryTable.innerHTML = rows
    .map(
      (row) => `
        <tr>
          <td>${escapeHtml(row.workerName)}</td>
          <td>${escapeHtml(row.clientName)}</td>
          <td>${formatDate(row.workDate)}</td>
          <td>${formatHours(row.workHours)}</td>
          <td>${formatGongsu(row.gongsu)}</td>
        </tr>
      `
    )
    .join("");
}

function updateManualPreview() {
  if (!els.manualPreview || !els.manualStartTime || !els.manualEndTime || !els.manualBreakMinutes) {
    return;
  }

  const result = calculateWorkMetrics(
    els.manualStartTime.value,
    els.manualEndTime.value,
    Number(els.manualBreakMinutes.value || 0)
  );

  if (!result) {
    els.manualPreview.innerHTML = `
      <strong>공수 계산 미리보기</strong>
      <span>시작시간, 종료시간, 휴게시간을 입력하면 실근무와 공수가 자동 계산됩니다.</span>
    `;
    return;
  }

  els.manualPreview.innerHTML = `
    <strong>실근무 ${formatHours(result.workHours)} / 공수 ${formatGongsu(result.gongsu)}</strong>
    <span>8시간 기준 1.0, 이후 1시간당 0.1 추가</span>
  `;
}

function calculateWorkMetrics(startTime, endTime, breakMinutes) {
  if (!startTime || !endTime) {
    return null;
  }

  const start = new Date(startTime);
  const end = new Date(endTime);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end <= start) {
    return null;
  }

  const totalMinutes = (end.getTime() - start.getTime()) / 60000;
  const netMinutes = Math.max(0, totalMinutes - Math.max(0, breakMinutes));
  const workHours = Math.round((netMinutes / 60) * 10) / 10;
  let gongsu = 0;

  if (workHours > 0 && workHours <= 8) {
    gongsu = Math.round((workHours / 8) * 10) / 10;
  } else if (workHours > 8) {
    gongsu = Math.round((1 + (workHours - 8) * 0.1) * 10) / 10;
  }

  return {
    workHours,
    gongsu
  };
}

function saveAndRender() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  renderAll();
}

function loadState() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(seedData));
    return structuredClone(seedData);
  }

  try {
    const parsed = JSON.parse(raw);
    return {
      requests: parsed.requests || [],
      workers: parsed.workers || [],
      assignments: parsed.assignments || [],
      attendance: (parsed.attendance || []).map((item) => ({
        assignmentId: item.assignmentId,
        checkIn: item.checkIn || "",
        checkOut: item.checkOut || "",
        manualStartTime: item.manualStartTime || "",
        manualEndTime: item.manualEndTime || "",
        breakMinutes: Number(item.breakMinutes || 0),
        workHours: Number(item.workHours || 0),
        gongsu: Number(item.gongsu || 0)
      }))
    };
  } catch (error) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(seedData));
    return structuredClone(seedData);
  }
}

function getRequest(id) {
  return state.requests.find((item) => item.id === id);
}

function getWorker(id) {
  return state.workers.find((item) => item.id === id);
}

function getAttendanceStatus(attendance) {
  if ((attendance?.manualStartTime || attendance?.checkIn) && (attendance?.manualEndTime || attendance?.checkOut)) {
    return "퇴근 완료";
  }
  if (attendance?.manualStartTime || attendance?.checkIn) {
    return "근무 중";
  }
  return "대기";
}

function countAssignedWorkers(requestId) {
  return state.assignments.filter((item) => item.requestId === requestId).length;
}

function emptyRow(message, colspan) {
  return `<tr><td colspan="${colspan}" class="empty">${message}</td></tr>`;
}

function renderStatus(value) {
  const className = value === "대기" ? "status-pill pending" : "status-pill";
  return `<span class="${className}">${value}</span>`;
}

function formatDate(value) {
  if (!value) {
    return "-";
  }
  return new Intl.DateTimeFormat("ko-KR", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).format(new Date(value));
}

function formatDateTime(value) {
  if (!value) {
    return "-";
  }
  return new Intl.DateTimeFormat("ko-KR", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date(value));
}

function formatHours(value) {
  if (!value) {
    return "-";
  }
  return `${Number(value).toFixed(1)}시간`;
}

function formatGongsu(value) {
  if (!value) {
    return "-";
  }
  return Number(value).toFixed(1);
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function todayDate() {
  return new Date().toISOString().slice(0, 10);
}
